<?php
declare(strict_types=1);
const APP_NAME = 'PocketChat';
const DB_PATH = __DIR__ . '/storage/chat.sqlite';
const UPLOAD_DIR = __DIR__ . '/uploads';
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB starter limit
const SESSION_NAME = 'pocketchat_session';
