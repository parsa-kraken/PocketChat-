<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!extension_loaded('pdo_sqlite')) {
        http_response_code(500);
        exit('PDO_SQLite is not enabled on this hosting account.');
    }
    $dir = dirname(DB_PATH);
    if (!is_dir($dir) && !mkdir($dir, 0750, true)) throw new RuntimeException('Cannot create storage directory.');
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    return $pdo;
}

function installed(): bool {
    return is_file(DB_PATH) && (int)db()->query("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='users'")->fetchColumn() > 0;
}

function start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'httponly' => true, 'secure' => !empty($_SERVER['HTTPS']),
        'samesite' => 'Lax', 'path' => '/'
    ]);
    session_start();
}

function json_out(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function body(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : $_POST;
}

function csrf_token(): string {
    start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function require_csrf(): void {
    start_session();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) json_out(['error'=>'Invalid CSRF token'], 419);
}

function current_user(): ?array {
    start_session();
    if (empty($_SESSION['uid'])) return null;
    $q = db()->prepare("SELECT id, public_id, username, display_name, role, status, avatar, created_at FROM users WHERE id=?");
    $q->execute([$_SESSION['uid']]);
    $u = $q->fetch();
    if (!$u || $u['status'] !== 'approved') return null;
    return $u;
}

function require_user(): array {
    $u = current_user();
    if (!$u) json_out(['error'=>'Authentication required or account awaiting approval'], 401);
    return $u;
}

function require_owner(): array {
    $u = require_user();
    if ($u['role'] !== 'owner') json_out(['error'=>'Forbidden'], 403);
    return $u;
}

function init_schema(): void {
    $sql = [
    "CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
      status TEXT NOT NULL DEFAULT 'pending', avatar TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen TEXT
    )",
    "CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL CHECK(type IN ('direct','group','channel')),
      title TEXT, owner_id INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    )",
    "CREATE TABLE IF NOT EXISTS conversation_members (
      conversation_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      role TEXT NOT NULL DEFAULT 'member', joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(conversation_id,user_id),
      FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id INTEGER NOT NULL,
      sender_id INTEGER NOT NULL, body TEXT NOT NULL DEFAULT '', attachment_name TEXT,
      attachment_path TEXT, attachment_mime TEXT, attachment_size INTEGER,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
      FOREIGN KEY(sender_id) REFERENCES users(id)
    )",
    "CREATE TABLE IF NOT EXISTS login_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT NOT NULL,
      success INTEGER NOT NULL, ip TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
    "CREATE INDEX IF NOT EXISTS idx_messages_conv_id ON messages(conversation_id,id)",
    "CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)"
    ];
    foreach ($sql as $s) db()->exec($s);
}
