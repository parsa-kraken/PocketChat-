# PocketChat

Self-hosted chat starter for shared PHP hosting / DirectAdmin.

## Requirements
- PHP 8.1+
- PDO SQLite extension (`pdo_sqlite`)
- Fileinfo extension
- Writable `storage/` and `uploads/` directories
- HTTPS strongly recommended

## Install
1. Upload and extract this folder into your domain's `public_html` (or document root).
2. Ensure `storage/` and `uploads/` are writable by PHP (usually 750/770 depending on host).
3. Visit `/install.php` and create the first owner account.
4. After installation, delete `install.php` from the server (the installer also locks itself after setup).
5. Sign in. New registrations are created as `pending` and are restricted until approved by the owner.
6. In production, configure PHP `upload_max_filesize` and `post_max_size` to suit your desired media limits.

## Important
- This is an MVP starter, not a fully audited production messenger.
- Polling is used instead of WebSockets.
- SQLite is created automatically in `storage/chat.sqlite`.
- Uploaded files are stored under `uploads/`; direct access is denied by `.htaccess` on Apache. Downloads are served through an authenticated API endpoint.
- Set a strong owner password and use HTTPS.
- Back up `storage/chat.sqlite` and `uploads/` together.
