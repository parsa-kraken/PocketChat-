<?php
require_once __DIR__ . '/system.php';
if (is_file(DB_PATH) && installed()) { http_response_code(403); exit('PocketChat is already installed. Remove install.php from the server.'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!extension_loaded('pdo_sqlite')) throw new RuntimeException('PDO_SQLite is not enabled.');
        if (!is_dir(__DIR__.'/storage')) mkdir(__DIR__.'/storage',0750,true);
        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0750,true);
        init_schema();
        $username = strtolower(trim($_POST['username'] ?? ''));
        $display = trim($_POST['display_name'] ?? '');
        $password = $_POST['password'] ?? '';
        if (!preg_match('/^[a-zA-Z0-9_]{3,24}$/',$username)) throw new RuntimeException('Username must be 3-24 letters, numbers or underscores.');
        if (mb_strlen($display) < 2 || mb_strlen($password) < 12) throw new RuntimeException('Display name must be at least 2 characters and password at least 12 characters.');
        $count = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
        if ($count !== 0) throw new RuntimeException('Owner account already exists.');
        $stmt = db()->prepare("INSERT INTO users(public_id,username,display_name,password_hash,role,status) VALUES(?,?,?,?, 'owner','approved')");
        $stmt->execute(['PC-'.strtoupper(bin2hex(random_bytes(5))),$username,$display,password_hash($password,PASSWORD_DEFAULT)]);
        header('Location: index.html?installed=1'); exit;
    } catch (Throwable $e) { $error = $e->getMessage(); }
}
?>
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PocketChat Setup</title>
<style>body{font:16px system-ui;background:#eef1f7;display:grid;place-items:center;min-height:100vh;margin:0;color:#182033}.card{background:white;padding:28px;border-radius:22px;width:min(420px,calc(100% - 40px));box-shadow:0 18px 50px #24324a22}input,button{box-sizing:border-box;width:100%;padding:13px;margin:8px 0;border:1px solid #d8deea;border-radius:12px;font:inherit}button{background:#1677e8;color:white;border:0;font-weight:700;cursor:pointer}.err{color:#b42318}</style>
<div class="card"><h1>PocketChat setup</h1><p>Create the first account. This account becomes the permanent owner.</p><?php if($error): ?><p class="err"><?=htmlspecialchars($error)?></p><?php endif; ?><form method="post"><input name="display_name" placeholder="Display name" required><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password (12+ characters)" minlength="12" required><button>Create owner account</button></form></div></html>
