<?php
require_once __DIR__ . '/system.php';
start_session();
if (!installed()) json_out(['error'=>'Not installed. Visit install.php'], 503);
$action = $_GET['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') require_csrf();

if ($action === 'bootstrap') {
    $u = current_user();
    json_out(['csrf'=>csrf_token(),'user'=>$u,'installed'=>true]);
}
if ($action === 'register' && $_SERVER['REQUEST_METHOD']==='POST') {
    $d=body(); $username=strtolower(trim($d['username']??'')); $name=trim($d['display_name']??''); $pass=$d['password']??'';
    if (!preg_match('/^[a-z0-9_]{3,24}$/',$username) || mb_strlen($name)<2 || mb_strlen($pass)<12) json_out(['error'=>'Check your details. Password must be at least 12 characters.'],422);
    try {
        $q=db()->prepare("INSERT INTO users(public_id,username,display_name,password_hash,status) VALUES(?,?,?,?, 'pending')");
        $q->execute(['PC-'.strtoupper(bin2hex(random_bytes(5))),$username,$name,password_hash($pass,PASSWORD_DEFAULT)]);
        json_out(['ok'=>true,'message'=>'Registration submitted. Wait for owner approval.']);
    } catch(Throwable $e) { json_out(['error'=>'Username may already be taken.'],409); }
}
if ($action === 'login' && $_SERVER['REQUEST_METHOD']==='POST') {
    $d=body(); $username=strtolower(trim($d['username']??'')); $q=db()->prepare('SELECT * FROM users WHERE username=?'); $q->execute([$username]); $u=$q->fetch();
    $ok=$u && password_verify($d['password']??'', $u['password_hash']);
    $log=db()->prepare('INSERT INTO login_events(user_id,username,success,ip) VALUES(?,?,?,?)');
    $log->execute([$u['id']??null,$username,$ok?1:0,$_SERVER['REMOTE_ADDR']??'']);
    if (!$ok) json_out(['error'=>'Invalid username or password'],401);
    if ($u['status']==='blocked') json_out(['error'=>'This account is blocked'],403);
    if ($u['status']!=='approved') json_out(['error'=>'Your account is awaiting owner approval'],403);
    session_regenerate_id(true); $_SESSION['uid']=$u['id']; csrf_token(); json_out(['ok'=>true]);
}
if ($action === 'logout') { $_SESSION=[]; session_destroy(); json_out(['ok'=>true]); }

$me=require_user();
if ($action === 'users') {
    $term=trim($_GET['q']??''); $q=db()->prepare("SELECT id,public_id,username,display_name,role,avatar,last_seen FROM users WHERE status='approved' AND (username LIKE ? OR display_name LIKE ?) AND id<>? ORDER BY display_name LIMIT 50");
    $like='%'.$term.'%'; $q->execute([$like,$like,$me['id']]); json_out(['users'=>$q->fetchAll()]);
}
if ($action === 'admin_users') {
    require_owner(); $rows=db()->query("SELECT id,public_id,username,display_name,role,status,created_at,last_seen FROM users ORDER BY created_at DESC")->fetchAll(); json_out(['users'=>$rows]);
}
if ($action === 'admin_action' && $_SERVER['REQUEST_METHOD']==='POST') {
    require_owner(); $d=body(); $id=(int)($d['id']??0); $status=$d['status']??'';
    if (!in_array($status,['approved','blocked','pending','rejected'],true)) json_out(['error'=>'Invalid status'],422);
    $q=db()->prepare("UPDATE users SET status=? WHERE id=? AND role<>'owner'"); $q->execute([$status,$id]); json_out(['ok'=>true]);
}
if ($action === 'create_conversation' && $_SERVER['REQUEST_METHOD']==='POST') {
    $d=body(); $type=$d['type']??'group'; $title=trim($d['title']??''); $ids=array_unique(array_map('intval',$d['user_ids']??[]));
    if (!in_array($type,['group','channel','direct'],true)) json_out(['error'=>'Invalid type'],422);
    if ($type!=='direct' && mb_strlen($title)<2) json_out(['error'=>'Title required'],422);
    if ($type==='direct' && count($ids)!==1) json_out(['error'=>'Choose one user'],422);
    $pdo=db(); $pdo->beginTransaction();
    $q=$pdo->prepare('INSERT INTO conversations(type,title,owner_id) VALUES(?,?,?)'); $q->execute([$type,$title?:null,$me['id']]); $cid=(int)$pdo->lastInsertId();
    $m=$pdo->prepare('INSERT INTO conversation_members(conversation_id,user_id,role) VALUES(?,?,?)'); $m->execute([$cid,$me['id'],'owner']);
    foreach($ids as $id){ if($id===$me['id']) continue; $check=$pdo->prepare("SELECT id FROM users WHERE id=? AND status='approved'"); $check->execute([$id]); if($check->fetch()) $m->execute([$cid,$id,'member']); }
    $pdo->commit(); json_out(['ok'=>true,'conversation_id'=>$cid]);
}
if ($action === 'conversations') {
    $q=db()->prepare("SELECT c.id,c.type,c.title,c.created_at FROM conversations c JOIN conversation_members m ON m.conversation_id=c.id WHERE m.user_id=? ORDER BY c.id DESC");
    $q->execute([$me['id']]); json_out(['conversations'=>$q->fetchAll()]);
}
if ($action === 'messages') {
    $cid=(int)($_GET['conversation_id']??0); $q=db()->prepare('SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?'); $q->execute([$cid,$me['id']]); if(!$q->fetch()) json_out(['error'=>'Forbidden'],403);
    $after=(int)($_GET['after']??0); $q=db()->prepare("SELECT m.id,m.body,m.attachment_name,m.attachment_mime,m.created_at,u.display_name,u.public_id FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=? AND m.id>? ORDER BY m.id ASC LIMIT 100"); $q->execute([$cid,$after]); json_out(['messages'=>$q->fetchAll()]);
}
if ($action === 'send' && $_SERVER['REQUEST_METHOD']==='POST') {
    $cid=(int)($_POST['conversation_id']??0); $message=trim($_POST['message']??'');
    $q=db()->prepare('SELECT 1 FROM conversation_members WHERE conversation_id=? AND user_id=?'); $q->execute([$cid,$me['id']]); if(!$q->fetch()) json_out(['error'=>'Forbidden'],403);
    $attachment=null; $mime=null; $size=null; $original=null;
    if(isset($_FILES['file']) && $_FILES['file']['error']!==UPLOAD_ERR_NO_FILE){
        $f=$_FILES['file']; if($f['error']!==UPLOAD_ERR_OK || $f['size']>MAX_UPLOAD_BYTES) json_out(['error'=>'Upload failed or file exceeds 25MB'],422);
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        $allowed=['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','application/pdf','text/plain'];
        if(!in_array($mime,$allowed,true)) json_out(['error'=>'File type not allowed'],415);
        $ext=match($mime){'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','video/mp4'=>'mp4','video/webm'=>'webm','application/pdf'=>'pdf','text/plain'=>'txt',default=>'bin'};
        $name=bin2hex(random_bytes(16)).'.'.$ext; if(!move_uploaded_file($f['tmp_name'],UPLOAD_DIR.'/'.$name)) json_out(['error'=>'Cannot save upload'],500);
        $attachment=$name; $original=basename($f['name']); $size=(int)$f['size'];
    }
    if($message==='' && !$attachment) json_out(['error'=>'Empty message'],422);
    $q=db()->prepare('INSERT INTO messages(conversation_id,sender_id,body,attachment_name,attachment_path,attachment_mime,attachment_size) VALUES(?,?,?,?,?,?,?)');
    $q->execute([$cid,$me['id'],$message,$original,$attachment,$mime,$size]); json_out(['ok'=>true,'id'=>(int)db()->lastInsertId()]);
}
if ($action === 'download') {
    $id=(int)($_GET['id']??0); $q=db()->prepare('SELECT m.*,cm.user_id FROM messages m JOIN conversation_members cm ON cm.conversation_id=m.conversation_id WHERE m.id=? AND cm.user_id=?'); $q->execute([$id,$me['id']]); $m=$q->fetch();
    if(!$m || !$m['attachment_path']) { http_response_code(404); exit; }
    $path=UPLOAD_DIR.'/'.$m['attachment_path']; if(!is_file($path)){http_response_code(404);exit;}
    header('Content-Type: '.$m['attachment_mime']); header('Content-Disposition: attachment; filename="'.rawurlencode($m['attachment_name']).'"'); header('Content-Length: '.filesize($path)); readfile($path); exit;
}
json_out(['error'=>'Unknown action'],404);
